package com.example.mycalculator

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    private val numbers = ArrayList<Int>()
    private lateinit var textViewElements : TextView


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val addButton: Button = findViewById(R.id.add)
        val subButton: Button = findViewById(R.id.sub)


        addButton.setOnClickListener {
            if (numbers.size <10){
                val newNumber = (1..100).random()
                numbers.add(newNumber)
            }else {
                textViewElements.text = "List is full"
            }
        }
        subButton.setOnClickListener {
            numbers.sum()
            textViewElements.text = "Subtract"
        }

    }

}

fun main(){
    val scan = Scanner(System. `in`)
    println("Please Enter Your Choice (1-6)")
    val choice=scan.nextInt()
    println("Please Enter Value Of 1st Number")
    val num1 = scan.nextDouble()
    println("{lease Enter Value For 2nd Number")
    val num2 =scan.nextDouble()
    for (i in 0..10){
        print("Done")
    }
    when (choice){
        1 -> {
            val ans = num1 + num2
            println("The addition of $num1 + $num2 =$ans")}
        2 -> {
            val ans = num1 - num2
            println("The difference of $num1 - $num2 =$ans")}
        3 -> {
            val ans = num1 * num2
            println("The product of $num1 x $num2 =$ans")}
        4 ->{
            if (num2 > 0.0){
                val ans = num1 / num2
                println ("Division of $num1 / $num2 =$ans")
            }else {
                println("Division of zero is not allowed")
            }
        }
        5 -> {
            val powNum = num1.pow(num2)
            println("The power of $num1 ^ $num2 = $powNum")
        }
        6 -> {
            val str1 = sqrt(num1)
            println("The squareRoot of $num1 = $str1")
            val str2 = sqrt(num2)
            println("The squareRoot of $num2 = $str2")
        }
    }
}